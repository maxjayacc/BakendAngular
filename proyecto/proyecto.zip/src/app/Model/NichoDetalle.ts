export class NichoDetalle {
    constructor(
            public Cantidad: number,
            public Item: string,
            public Lote: string,
            public Marca: string,
            ) {}
    }
