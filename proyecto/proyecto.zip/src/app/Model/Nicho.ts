export class Nicho {
    constructor(
            public Cantidad: number,
            public DescripcionUbicacion: string,
            public NichoNumero: string,
            public Nivel: string,
            public PorcentajeVolumen: number,
            ) {}
    }
