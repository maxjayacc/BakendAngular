export class JW {
    constructor(
            public name: string,
            public password: string,
            ) {}
    }