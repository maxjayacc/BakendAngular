export class Loggin {
    constructor(
            public name: string,
            public password: string,
            ) {}
    }
