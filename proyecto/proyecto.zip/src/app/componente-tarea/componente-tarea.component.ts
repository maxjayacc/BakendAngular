import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-componente-tarea',
  templateUrl: './componente-tarea.component.html',
  styleUrls: ['./componente-tarea.component.css']
})
export class ComponenteTareaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
