import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calimod',
  templateUrl: './calimod.component.html',
  styleUrls: ['./calimod.component.css']
})
export class CalimodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
