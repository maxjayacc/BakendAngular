export const ConfiguracionJava = {
    url: 'http://5.189.168.151:8585/',
    wsProveedor: 'api',
};


